package com.example.salud_prueba1

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MenuActivity : AppCompatActivity() {
    private lateinit var btnCitas: Button
    private lateinit var btnMedicamentos: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)

        // Referenciar vistas
        btnCitas = findViewById(R.id.btnCitas)
        btnMedicamentos = findViewById(R.id.btnMedicamentos)

        // Acción para el botón de Citas médicas
        btnCitas.setOnClickListener {
            val intent = Intent(this, CitasActivity::class.java)
            startActivity(intent)
        }

        // Acción para el botón de Medicamentos
        btnMedicamentos.setOnClickListener {
            val intent = Intent(this, MedicamentosActivity::class.java)
            startActivity(intent)
        }
    }
}
