package com.example.salud_prueba1

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    private lateinit var etCorreoLogin: EditText
    private lateinit var etPasswordLogin: EditText
    private lateinit var cbRecordarme: CheckBox
    private lateinit var btnIniciarSesion: Button
    private lateinit var tvOlvido: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Aquí colocas el nombre real de tu layout XML
        setContentView(R.layout.activity_inicio_sesion)

        // Inicializamos componentes
        etCorreoLogin = findViewById(R.id.etCorreoLogin)
        etPasswordLogin = findViewById(R.id.etPasswordLogin)
        cbRecordarme = findViewById(R.id.cbRecordarme)
        btnIniciarSesion = findViewById(R.id.btnIniciarSesion)
        tvOlvido = findViewById(R.id.tvOlvido)

        // Acción al presionar Iniciar Sesión
        btnIniciarSesion.setOnClickListener {
            val correo = etCorreoLogin.text.toString().trim()
            val password = etPasswordLogin.text.toString().trim()

            if (correo.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Debes ingresar correo y contraseña", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Aquí iría tu lógica real de autenticación
            if (correo == "admin@correo.com" && password == "1234") {
                Toast.makeText(this, "Inicio de sesión exitoso", Toast.LENGTH_SHORT).show()

                // Si quieres recordar al usuario puedes guardar en SharedPreferences
                if (cbRecordarme.isChecked) {
                    val prefs = getSharedPreferences("loginPrefs", MODE_PRIVATE)
                    prefs.edit().putString("correo", correo).apply()
                }

                // Ir a otra Activity
                val intent = Intent(this, MenuActivity::class.java)
                startActivity(intent)
                finish()
            } else {
                Toast.makeText(this, "Correo o contraseña incorrectos", Toast.LENGTH_SHORT).show()
            }
        }

        // Acción al presionar ¿Olvidaste tu contraseña?
        tvOlvido.setOnClickListener {
            Toast.makeText(this, "Función recuperar contraseña próximamente", Toast.LENGTH_SHORT).show()
        }
    }
}
