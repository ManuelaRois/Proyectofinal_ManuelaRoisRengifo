package com.example.salud_prueba1

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.salud_prueba1.LoginActivity
import com.example.salud_prueba1.MenuActivity
import com.example.salud_prueba1.R
import com.example.salud_prueba1.RegistroUserActivity

class FirstView : AppCompatActivity() {

    private val PREFS_NAME = "salud_prefs"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_first)

        val prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)

        // Si ya está logueado, va directo al menú principal
        if (prefs.getBoolean("isLoggedIn", false)) {
            startActivity(Intent(this, MenuActivity::class.java))
            finish()
            return
        }

        val btnRegistro = findViewById<Button>(R.id.btnRegistro)
        val btnIniciarSesion = findViewById<Button>(R.id.btnIniciar_Sesion)

        btnRegistro.setOnClickListener {
            // Abrir la actividad de registro
            startActivity(Intent(this, RegistroUserActivity::class.java))
        }

        btnIniciarSesion.setOnClickListener {
            // Abrir la actividad de inicio de sesión
            startActivity(Intent( this, LoginActivity::class.java))
        }
    }
}