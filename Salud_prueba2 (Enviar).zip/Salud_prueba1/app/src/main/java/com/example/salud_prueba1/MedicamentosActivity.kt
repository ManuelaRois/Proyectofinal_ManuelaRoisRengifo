package com.example.salud_prueba1

import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MedicamentosActivity : AppCompatActivity() {

    // Referencias a los elementos de la vista
    private lateinit var etNombre: EditText
    private lateinit var etDosis: EditText
    private lateinit var etHorario: EditText
    private lateinit var cbTomado: CheckBox
    private lateinit var btnAgregar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_medicamentos)

        // Inicializamos las vistas
        etNombre = findViewById(R.id.etNombre)
        etDosis = findViewById(R.id.etDosis)
        etHorario = findViewById(R.id.etHorario)
        cbTomado = findViewById(R.id.cbTomado)
        btnAgregar = findViewById(R.id.btnAgregar)

        // Acción al pulsar el botón Agregar
        btnAgregar.setOnClickListener {
            val nombre = etNombre.text.toString().trim()
            val dosis = etDosis.text.toString().trim()
            val horario = etHorario.text.toString().trim()
            val tomado = cbTomado.isChecked

            if (nombre.isEmpty() || dosis.isEmpty() || horario.isEmpty()) {
                Toast.makeText(this, "Por favor completa todos los campos", Toast.LENGTH_SHORT).show()
            } else {
                // Aquí puedes guardar los datos en BD, lista, etc.
                val mensaje = "Medicamento: $nombre\nDosis: $dosis\nHorario: $horario\nTomado: $tomado"
                Toast.makeText(this, mensaje, Toast.LENGTH_LONG).show()

                // Opcional: limpiar campos después de agregar
                etNombre.text.clear()
                etDosis.text.clear()
                etHorario.text.clear()
                cbTomado.isChecked = false
            }
        }
    }
}
