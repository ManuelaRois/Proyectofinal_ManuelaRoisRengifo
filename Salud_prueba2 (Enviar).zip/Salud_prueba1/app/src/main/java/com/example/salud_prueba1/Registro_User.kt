package com.example.salud_prueba1

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class RegistroUserActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registro_user)

        // VARIABLES
        val etCedula = findViewById<EditText>(R.id.etCedula)
        val etNombre = findViewById<EditText>(R.id.etNombre)
        val etFecha = findViewById<EditText>(R.id.etFecha)
        val etCorreo = findViewById<EditText>(R.id.etCorreo)
        val etGenero = findViewById<EditText>(R.id.etGenero)
        val etAlergias = findViewById<EditText>(R.id.etAlergias)
        val etEnfermedades = findViewById<EditText>(R.id.etEnfermedades)
        val etContacto = findViewById<EditText>(R.id.etContacto)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val cbTerminos = findViewById<CheckBox>(R.id.cbTerminos)
        val btnRegistrarse = findViewById<Button>(R.id.btnRegistrarse)

        // Al pulsar el botón Registrarse
        btnRegistrarse.setOnClickListener {
            val cedula = etCedula.text.toString().trim()
            val nombre = etNombre.text.toString().trim()
            val fecha = etFecha.text.toString().trim()
            val correo = etCorreo.text.toString().trim()
            val genero = etGenero.text.toString().trim()
            val alergias = etAlergias.text.toString().trim()
            val enfermedades = etEnfermedades.text.toString().trim()
            val contacto = etContacto.text.toString().trim()
            val password = etPassword.text.toString().trim()

            // Validación básica
            if (cedula.isEmpty() || nombre.isEmpty() || fecha.isEmpty() ||
                correo.isEmpty() || genero.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Completa todos los campos obligatorios", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (!cbTerminos.isChecked) {
                Toast.makeText(this, "Debes aceptar los términos y condiciones", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            //  lógica para guardar el usuario en la BD, API, etc.
            Toast.makeText(this, "Usuario registrado correctamente", Toast.LENGTH_LONG).show()

            // Limpiar campos después
            etCedula.text.clear()
            etNombre.text.clear()
            etFecha.text.clear()
            etCorreo.text.clear()
            etGenero.text.clear()
            etAlergias.text.clear()
            etEnfermedades.text.clear()
            etContacto.text.clear()
            etPassword.text.clear()
            cbTerminos.isChecked = false
        }
    }
}
