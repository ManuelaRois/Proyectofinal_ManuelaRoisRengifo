package com.example.salud_prueba1

import android.os.Bundle
import android.text.TextUtils
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class CitasActivity : AppCompatActivity() {

    // Declaramos las vistas
    private lateinit var etFecha: EditText
    private lateinit var etHora: EditText
    private lateinit var etDoctor: EditText
    private lateinit var etLugar: EditText
    private lateinit var btnAgregarCita: Button
    private lateinit var lvCitas: ListView

    // Lista para almacenar las citas en memoria
    private val listaCitas = mutableListOf<String>()
    private lateinit var adaptador: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // CORREGIDO: usa el layout que sí existe
        setContentView(R.layout.activity_citas)

        // Inicializamos vistas
        etFecha = findViewById(R.id.etFecha)
        etHora = findViewById(R.id.etHora)
        etDoctor = findViewById(R.id.etDoctor)
        etLugar = findViewById(R.id.etLugar)
        btnAgregarCita = findViewById(R.id.btnAgregarCita)
        lvCitas = findViewById(R.id.lvCitas)

        // Configuramos el adaptador del ListView
        adaptador = ArrayAdapter(this, android.R.layout.simple_list_item_1, listaCitas)
        lvCitas.adapter = adaptador

        // Acción al presionar el botón
        btnAgregarCita.setOnClickListener {
            val fecha = etFecha.text.toString().trim()
            val hora = etHora.text.toString().trim()
            val doctor = etDoctor.text.toString().trim()
            val lugar = etLugar.text.toString().trim()

            if (TextUtils.isEmpty(fecha) || TextUtils.isEmpty(hora) ||
                TextUtils.isEmpty(doctor) || TextUtils.isEmpty(lugar)
            ) {
                Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show()
            } else {
                // Creamos el texto para mostrar la cita
                val cita = "📅 $fecha - ⏰ $hora - 👨‍⚕️ $doctor - 🏥 $lugar"
                listaCitas.add(cita)
                adaptador.notifyDataSetChanged()

                // Limpiamos campos
                etFecha.text.clear()
                etHora.text.clear()
                etDoctor.text.clear()
                etLugar.text.clear()

                Toast.makeText(this, "Cita agregada correctamente", Toast.LENGTH_SHORT).show()
            }
        }

        // Opción: Eliminar cita al hacer click largo
        lvCitas.setOnItemLongClickListener { _, _, position, _ ->
            listaCitas.removeAt(position)
            adaptador.notifyDataSetChanged()
            Toast.makeText(this, "Cita eliminada", Toast.LENGTH_SHORT).show()
            true
        }
    }
}

