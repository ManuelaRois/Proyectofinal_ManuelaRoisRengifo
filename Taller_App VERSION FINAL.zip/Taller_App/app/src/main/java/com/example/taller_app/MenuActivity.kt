package com.example.taller_app

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.card.MaterialCardView

class MenuActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)

        val cardCalculadora = findViewById<MaterialCardView>(R.id.cardCalculadora)
        val cardPromedio = findViewById<MaterialCardView>(R.id.cardPromedio)
        val cardConversor = findViewById<MaterialCardView>(R.id.cardConversor)
        val cardPropinas = findViewById<MaterialCardView>(R.id.cardPropinas)

        cardCalculadora.setOnClickListener {
            val intent = Intent(this, cardPropinas::class.java)
            startActivity(intent)
        }

        cardPromedio.setOnClickListener {
            val intent = Intent(this, cardConversor::class.java)
            startActivity(intent)
        }

        cardConversor.setOnClickListener {
            val intent = Intent(this, cardPromedio::class.java)
            startActivity(intent)
        }

        cardPropinas.setOnClickListener {
            val intent = Intent(this, cardCalculadora::class.java)
            startActivity(intent)
        }
    }
}